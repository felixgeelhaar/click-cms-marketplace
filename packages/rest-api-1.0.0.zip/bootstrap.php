<?php

declare(strict_types=1);

require_once __DIR__ . '/../../src/Application/Plugin/BasePlugin.php';

class Plugin_rest_api extends \Click\Cms\Application\Plugin\BasePlugin
{
    public function getPluginId(): string
    {
        return 'rest-api';
    }

    public function getPluginName(): string
    {
        return 'REST API';
    }

    public function install(): bool
    {
        return true;
    }

    public function activate(): bool
    {
        return true;
    }

    public function deactivate(): bool
    {
        return true;
    }

    public function hook_api_routes(array $params): array
    {
        return [
            // Pages
            'GET /api/pages' => [$this, 'getPages'],
            'GET /api/pages/:slug' => [$this, 'getPage'],
            'POST /api/pages' => [$this, 'createPage'],
            'PUT /api/pages/:slug' => [$this, 'updatePage'],
            'DELETE /api/pages/:slug' => [$this, 'deletePage'],
            
            // Users
            'GET /api/users' => [$this, 'getUsers'],
            'GET /api/users/:username' => [$this, 'getUser'],
            'POST /api/users' => [$this, 'createUser'],
            'PUT /api/users/:username' => [$this, 'updateUser'],
            'DELETE /api/users/:username' => [$this, 'deleteUser'],
            
            // Media
            'GET /api/media' => [$this, 'getMedia'],
            'GET /api/media/:filename' => [$this, 'getMediaFile'],

            // Plugins
            'GET /api/plugins' => [$this, 'getPlugins'],

            // System
            'GET /api/info' => [$this, 'getInfo'],
        ];
    }

    public function getInfo(): array
    {
        return [
            'data' => [
                'name' => 'Click CMS',
                'version' => '0.1.0',
                'endpoints' => [
                    'pages' => '/api/pages',
                    'users' => '/api/users',
                    'media' => '/api/media',
                ],
            ],
        ];
    }

    public function getPages(): array
    {
        $contentService = $this->pluginManager->getContentService();
        $pages = $contentService->pages();
        
        return [
            'data' => array_map(fn($p) => $p->toArray(), $pages),
        ];
    }

    public function getPage(string $slug): array
    {
        $contentService = $this->pluginManager->getContentService();
        $page = $contentService->page($slug);
        
        if (!$page) {
            return ['error' => 'Page not found', 'status' => 404];
        }
        
        return ['data' => $page->toArray()];
    }

    public function createPage(): array
    {
        $data = $this->getJsonBody();
        
        if (!isset($data['title']) && !isset($data['content'])) {
            return ['error' => 'Title or content required', 'status' => 400];
        }

        $slugInput = trim((string) ($data['slug'] ?? ''));
        if ($slugInput !== '') {
            $slug = $this->slugify($slugInput);
        } else {
            $slug = $this->slugify($data['title'] ?? 'untitled');
        }

        if ($slug === '') {
            $slug = 'untitled';
        }
        
        $contentService = $this->pluginManager->getContentService();
        
        if ($contentService->page($slug)) {
            return ['error' => 'Page already exists', 'status' => 409];
        }

        $content = \Click\Cms\Domain\Content\Content::create(
            \Click\Cms\Domain\ValueObjects\ContentKey::page($slug),
            $data
        );
        
        $contentService->save($content);
        
        return ['data' => $content->toArray(), 'status' => 201];
    }

    public function updatePage(string $slug): array
    {
        $data = $this->getJsonBody();
        $contentService = $this->pluginManager->getContentService();
        
        $page = $contentService->page($slug);
        
        if (!$page) {
            return ['error' => 'Page not found', 'status' => 404];
        }

        $updated = $page->update($data);
        $contentService->save($updated);
        
        return ['data' => $updated->toArray()];
    }

    public function deletePage(string $slug): array
    {
        $contentService = $this->pluginManager->getContentService();
        
        if (!$contentService->page($slug)) {
            return ['error' => 'Page not found', 'status' => 404];
        }

        $contentService->delete(\Click\Cms\Domain\ValueObjects\ContentKey::page($slug));
        
        return ['data' => ['deleted' => true, 'slug' => $slug]];
    }

    public function getUsers(): array
    {
        $contentService = $this->pluginManager->getContentService();
        $users = $contentService->all('user');
        
        return [
            'data' => array_map(fn($u) => $this->sanitizeUser($u->toArray()), $users),
        ];
    }

    public function getUser(string $username): array
    {
        $contentService = $this->pluginManager->getContentService();
        $user = $contentService->user($username);
        
        if (!$user) {
            return ['error' => 'User not found', 'status' => 404];
        }
        
        return ['data' => $this->sanitizeUser($user->toArray())];
    }

    public function createUser(): array
    {
        $data = $this->getJsonBody();
        
        if (!isset($data['email'])) {
            return ['error' => 'Email required', 'status' => 400];
        }

        if (empty($data['password'])) {
            return ['error' => 'Password required', 'status' => 400];
        }

        $passwordValidation = $this->validatePassword($data['password']);
        if ($passwordValidation !== null) {
            return ['error' => $passwordValidation, 'status' => 400];
        }

        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

        $username = $data['username'] ?? $this->slugify($data['email']);
        
        $contentService = $this->pluginManager->getContentService();
        
        if ($contentService->user($username)) {
            return ['error' => 'User already exists', 'status' => 409];
        }

        $content = \Click\Cms\Domain\Content\Content::create(
            \Click\Cms\Domain\ValueObjects\ContentKey::user($username),
            $data
        );
        
        $contentService->save($content);
        
        return ['data' => $content->toArray(), 'status' => 201];
    }

    public function updateUser(string $username): array
    {
        $data = $this->getJsonBody();
        $contentService = $this->pluginManager->getContentService();
        
        $user = $contentService->user($username);
        
        if (!$user) {
            return ['error' => 'User not found', 'status' => 404];
        }

        if (isset($data['password']) && $data['password'] !== '') {
            $passwordValidation = $this->validatePassword($data['password']);
            if ($passwordValidation !== null) {
                return ['error' => $passwordValidation, 'status' => 400];
            }
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        } else {
            unset($data['password']);
        }

        $updated = $user->update($data);
        $contentService->save($updated);
        
        return ['data' => $this->sanitizeUser($updated->toArray())];
    }

    public function deleteUser(string $username): array
    {
        $contentService = $this->pluginManager->getContentService();
        
        if (!$contentService->user($username)) {
            return ['error' => 'User not found', 'status' => 404];
        }

        $contentService->delete(\Click\Cms\Domain\ValueObjects\ContentKey::user($username));
        
        return ['data' => ['deleted' => true, 'username' => $username]];
    }

    public function getMedia(): array
    {
        $contentService = $this->pluginManager->getContentService();
        $media = $contentService->all('media');
        
        return [
            'data' => array_map(fn($m) => $m->toArray(), $media),
        ];
    }

    public function getMediaFile(string $filename): array
    {
        $contentService = $this->pluginManager->getContentService();
        $media = $contentService->get(\Click\Cms\Domain\ValueObjects\ContentKey::media($filename));
        
        if (!$media) {
            return ['error' => 'Media not found', 'status' => 404];
        }
        
        return ['data' => $media->toArray()];
    }

    public function getPlugins(): array
    {
        $plugins = $this->pluginManager->all();
        
        return [
            'data' => array_map(fn($p) => [
                'id' => $p->id->value,
                'name' => $p->name,
                'description' => $p->description,
                'version' => $p->version->value,
                'author' => $p->author,
                'state' => $p->state->value,
                'dependencies' => $p->dependencies,
                'hooks' => $p->hooks,
            ], $plugins),
        ];
    }

    private function getJsonBody(): array
    {
        $input = file_get_contents('php://input');
        
        if (empty($input)) {
            return $_POST;
        }
        
        $data = json_decode($input, true);
        
        return $data ?? [];
    }

    private function sanitizeUser(array $user): array
    {
        if (isset($user['data']['password'])) {
            $user['data']['password'] = null;
        }

        if (isset($user['password'])) {
            $user['password'] = null;
        }

        return $user;
    }

    private function validatePassword(string $password): ?string
    {
        $minLength = 8;

        if (strlen($password) < $minLength) {
            return 'Password must be at least ' . $minLength . ' characters.';
        }

        return null;
    }

    private function slugify(string $text): string
    {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9-]/', '-', $text);
        $text = preg_replace('/-+/', '-', $text);
        return trim($text, '-');
    }
}
