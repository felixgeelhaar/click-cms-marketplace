<?php

declare(strict_types=1);

use Click\Cms\Application\Plugin\BasePlugin;
use Click\Cms\Domain\Content\Content;

class Plugin_visual_builder extends BasePlugin
{
    public function getPluginId(): string
    {
        return 'visual-builder';
    }

    public function getPluginName(): string
    {
        return 'Visual Builder';
    }

    public function hook_web_render(array $params): ?string
    {
        $page = $params['page'] ?? null;
        if (!$page instanceof Content) {
            return null;
        }

        $data = $page->data ?? [];
        $builder = $data['builder'] ?? null;
        if (!is_array($builder)) {
            return null;
        }

        $title = htmlspecialchars($page->title(), ENT_QUOTES, 'UTF-8');
        $body = $this->renderBuilder($builder);

        return '<!doctype html><html><head><meta charset="utf-8"><title>' . $title . '</title></head><body>' . $body . '</body></html>';
    }

    private function renderBuilder(array $builder): string
    {
        $nodes = $builder['nodes'] ?? [];
        $rootId = $builder['root'] ?? null;
        if (!is_string($rootId) || !isset($nodes[$rootId])) {
            return '';
        }

        return $this->renderNode($nodes, $rootId);
    }

    private function renderNode(array $nodes, string $id): string
    {
        $node = $nodes[$id] ?? null;
        if (!is_array($node)) {
            return '';
        }

        $type = $node['type'] ?? 'section';
        $children = $node['children'] ?? [];
        $props = $node['props'] ?? [];
        $styles = $node['styles'] ?? [];
        $responsive = $node['responsive']['base'] ?? null;
        if (is_array($responsive)) {
            $props = array_merge($props, $responsive['props'] ?? []);
            $styles = array_merge($styles, $responsive['styles'] ?? []);
        }

        if ($type === 'grid' && isset($props['columns']) && !isset($styles['gridTemplateColumns'])) {
            $styles['display'] = $styles['display'] ?? 'grid';
            $styles['gridTemplateColumns'] = 'repeat(' . (int) $props['columns'] . ', minmax(0, 1fr))';
        }

        $styleAttr = $this->styleString($styles);
        $inner = '';
        foreach ($children as $childId) {
            if (!is_string($childId)) {
                continue;
            }
            $inner .= $this->renderNode($nodes, $childId);
        }

        if ($type === 'text') {
            $text = htmlspecialchars((string)($props['text'] ?? ''), ENT_QUOTES, 'UTF-8');
            return '<p' . $styleAttr . '>' . $text . '</p>';
        }

        if ($type === 'image') {
            $src = htmlspecialchars((string)($props['src'] ?? ''), ENT_QUOTES, 'UTF-8');
            $alt = htmlspecialchars((string)($props['alt'] ?? ''), ENT_QUOTES, 'UTF-8');
            return '<img src="' . $src . '" alt="' . $alt . '"' . $styleAttr . ' />';
        }

        if ($type === 'button') {
            $label = htmlspecialchars((string)($props['label'] ?? 'Button'), ENT_QUOTES, 'UTF-8');
            $href = htmlspecialchars((string)($props['href'] ?? '#'), ENT_QUOTES, 'UTF-8');
            return '<a href="' . $href . '"' . $styleAttr . '>' . $label . '</a>';
        }

        if ($type === 'spacer') {
            return '<div' . $styleAttr . '></div>';
        }

        $tag = $type === 'grid' ? 'div' : 'section';
        return '<' . $tag . $styleAttr . '>' . $inner . '</' . $tag . '>';
    }

    private function styleString(array $styles): string
    {
        if (empty($styles)) {
            return '';
        }

        $pairs = [];
        foreach ($styles as $key => $value) {
            if (!is_scalar($value)) {
                continue;
            }
            $pairs[] = $key . ':' . $value;
        }

        if (empty($pairs)) {
            return '';
        }

        return ' style="' . htmlspecialchars(implode(';', $pairs), ENT_QUOTES, 'UTF-8') . '"';
    }
}
